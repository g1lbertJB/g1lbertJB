#include "common.h"
__BEGIN_DECLS
#ifdef IMG3_SUPPORT
prange_t unpack(prange_t input, const char *key, const char *iv);
#endif
__END_DECLS
